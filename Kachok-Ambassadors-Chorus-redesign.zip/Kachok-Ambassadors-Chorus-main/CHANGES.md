# Redesign notes

## Palette (matches the logo)
- Primary: Navy `#081830`, Orange `#F09010`
- Secondary: Cream `#FFF6E8`, Steel `#5B7BA6`
- Every other hue class used in the codebase (emerald, rose, sky, violet, etc.) is remapped to these four in `src/index.css`.

## Typography
- Compact, mobile-first type scale in `src/index.css` (base text 14px, section titles 24–32px).
- Header wordmark uses `.brand-name`; hero headline uses `.hero-title`. Both keep their size.

## Sections
- Itinerary: rebuilt as a clean list with a "Next up" panel and countdown. Keeps search, filters, favourites, reminders, calendar export (Google / .ics), share, booking, PDF export, media viewer and admin add/edit/delete.
- Ministries and Leaders: restyled to a minimal grid. Keeps search, share, profile dialog, `?leader=` deep links, social links and admin controls.
- Hero: receives real events and gallery photos from App (the "Next up" card previously never loaded).

## Fixes
- Footer links for Ministries and Join Us now point at real section ids.
- Admin Cloudinary diagnostic: `POST /api/cloudinary-diagnostic` added on the server.

## Security and admin
- `requireAdmin` in server.ts re-enabled. Admin writes need a valid admin passcode or session token (sent as `x-admin-passcode`, which the admin panel already does).
- Leaders who sign in only with Google (no passcode) will need the admin passcode or session to save changes.

## M-Pesa receipts
- The callback at `/api/mpesa/callback` now saves each successful payment (stored once per receipt number) under the `receipts` collection.
- `GET /api/mpesa/receipts` (admin only) returns them, newest first. The admin panel sends the auth header.
- Receipts are saved as "Contributor" because the payment record does not carry the donor's name. Adding a name needs the donor name stored when the STK push is started.
- PDF receipts are not generated yet (`pdfUrl` is empty).
